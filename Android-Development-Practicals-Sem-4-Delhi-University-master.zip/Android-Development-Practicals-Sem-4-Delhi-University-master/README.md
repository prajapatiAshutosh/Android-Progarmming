1. These are codes for practical questions given in BSc (Hons) Computer Science Semester 4 guidelines for Android Development at University of Delhi.
2. "Link to Assignment Maker" text file contains a link of a Google form. Fill and submit it to get your Practical file(containing a Front page with your credentials, codes and outputs for all test cases) PDF within a minute on your email"
3. Enter your valid details while filling up "Assingment Bot" so that we can notify you for future practical files.

Link - https://forms.gle/yDZ2ooK4bDAAiaxW9
