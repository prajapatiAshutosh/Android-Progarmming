package com.example.practical11;

import android.app.Activity;

public class AndroidManifest extends Activity {
}
